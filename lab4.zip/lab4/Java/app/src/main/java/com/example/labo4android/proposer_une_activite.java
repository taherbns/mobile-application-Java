package com.example.labo4android;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class proposer_une_activite extends AppCompatActivity {
    private EditText editTextTitre;
    private EditText editTextDescription;
    private EditText editTextPrix;
    private EditText editTextDateDebut;
    private EditText editTextDateFin;
    private Button buttonProposer;
    private DatePickerDialog datePickerDebut, datePickerFin;
    private Calendar calendar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.proposer_une_activite);

        editTextTitre = findViewById(R.id.editTextTitre);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextPrix = findViewById(R.id.editTextPrix);
        editTextDateDebut = findViewById(R.id.editTextDateDebut);
        editTextDateFin = findViewById(R.id.editTextDateFin);
        buttonProposer = findViewById(R.id.buttonProposer);

        calendar = Calendar.getInstance();

        buttonProposer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                proposerActivite();
            }
        });

        setUpDatePickers();
    }

    private void setUpDatePickers() {
        editTextDateDebut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDebut.show();
            }
        });

        editTextDateFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerFin.show();
            }
        });

        datePickerDebut = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                        editTextDateDebut.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        datePickerFin = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                        editTextDateFin.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
    }

    private void proposerActivite() {
        String titre = editTextTitre.getText().toString();
        String description = editTextDescription.getText().toString();
        String prix = editTextPrix.getText().toString();
        String dateDebutt = editTextDateDebut.getText().toString();
        String dateFinn = editTextDateFin.getText().toString();

        String dateDebut = convertirDateMySQL(dateDebutt);
        String dateFin= convertirDateMySQL(dateFinn);


         MainActivity.dbWorker dbw = new MainActivity.dbWorker(this);
         dbw.execute(7, titre, dateDebut, dateFin, description, prix );
    }
    private String convertirDateMySQL(String date) {
        String[] elements = date.split("/");
        if (elements.length == 3) {
            String jour = elements[0];
            String mois = elements[1];
            String annee = elements[2];


            return annee + "-" + mois + "-" + jour;
        }
        return "";
    }

}
