    package com.example.labo4android;

    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.EditText;

    import androidx.annotation.Nullable;
    import androidx.appcompat.app.AppCompatActivity;

    public class inscription extends AppCompatActivity {
        private EditText editTextNom;
        private EditText editTextPrenom;
        private EditText editTextTel;
        private EditText editTextEmail;
        private EditText editTextUsername;
        private EditText editTextPassword;
        private Button buttonInscription;

        @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.inscription);

            editTextNom = findViewById(R.id.editTextNom);
            editTextPrenom = findViewById(R.id.editTextPrenom);
            editTextTel = findViewById(R.id.editTextTel);
            editTextEmail = findViewById(R.id.editTextEmail);
            editTextUsername = findViewById(R.id.editTextUsername);
            editTextPassword = findViewById(R.id.editTextPassword);
            buttonInscription = findViewById(R.id.buttonInscription);

            buttonInscription.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    inscription();
                }
            });
        }
        private void inscription() {
            String nom = editTextNom.getText().toString();
            String prenom = editTextPrenom.getText().toString();
            String tel = editTextTel.getText().toString();
            String email = editTextEmail.getText().toString();
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            MainActivity.dbWorker dbw = new MainActivity.dbWorker(this);
            dbw.execute(1, nom, prenom, tel, email, username, password);

        }

    }