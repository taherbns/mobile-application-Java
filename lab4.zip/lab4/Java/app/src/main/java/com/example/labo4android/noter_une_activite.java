package com.example.labo4android;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class noter_une_activite extends AppCompatActivity {
    private EditText editTextUserID;
    private EditText editTextActivityID;
    private EditText editTextNote;
    private Button buttonAjouterNote;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.noteract);

        editTextUserID = findViewById(R.id.editTextUserID);
        editTextActivityID = findViewById(R.id.editTextActivityID);
        editTextNote = findViewById(R.id.editTextNote);
        buttonAjouterNote = findViewById(R.id.buttonAjouterNote);

        buttonAjouterNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                inscrireNote();            }
        });
    }

    private void inscrireNote() {
        String id_util = editTextUserID.getText().toString().trim();
        String id_act = editTextActivityID.getText().toString().trim();
        String note = editTextNote.getText().toString().trim();
        MainActivity.dbWorker d = new MainActivity.dbWorker(this);
        d.execute(6,id_util,id_act,note);
    }
}
