package com.example.labo4android;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class note_moyenne extends AppCompatActivity {
    private EditText editTextIdActivity;
    private EditText editTextTitre;
    private Button buttonNoteMoyenne;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notemoyenne);
        editTextIdActivity = findViewById(R.id.editTextIdActivity);
        editTextTitre = findViewById(R.id.editTextTitre);
        buttonNoteMoyenne = findViewById(R.id.buttonCalculerNoteMoyenne);

        buttonNoteMoyenne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculerNoteMoyenne();
            }
        });


    }

    private void calculerNoteMoyenne() {
        String id_act = editTextIdActivity.getText().toString().trim();
        String titre = editTextTitre.getText().toString().trim();
        MainActivity.dbWorker d = new MainActivity.dbWorker(this);
        d.execute(5,id_act);

    }

}
