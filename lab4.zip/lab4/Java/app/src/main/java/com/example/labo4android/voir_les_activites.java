package com.example.labo4android;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class voir_les_activites extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.voir_activities);
        Button recuperer = findViewById(R.id.buttonActivities);
        listView = findViewById(R.id.listViewActivities);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        listView.setAdapter(adapter);
        recuperer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recupererActivivites();
            }
        });
    }

    private void recupererActivivites() {
        MainActivity.dbWorker dbw = new MainActivity.dbWorker(this);

        dbw.execute(2);
    }

}

