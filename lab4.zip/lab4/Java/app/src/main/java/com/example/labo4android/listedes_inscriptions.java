package com.example.labo4android;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class listedes_inscriptions extends AppCompatActivity {

    private EditText editTextIdAct;
    private Button buttonAfficherUtil;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listinscrit);

        editTextIdAct = findViewById(R.id.editTextIdAct);
        buttonAfficherUtil = findViewById(R.id.buttonAfficher);

        buttonAfficherUtil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                afficherlist();
            }
        });

    }

    private void afficherlist() {
        String id_act = editTextIdAct.getText().toString().trim();
        MainActivity.dbWorker d = new MainActivity.dbWorker(this);
        d.execute(3,id_act);
    }
}
