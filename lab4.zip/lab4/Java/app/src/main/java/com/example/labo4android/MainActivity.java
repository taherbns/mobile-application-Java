package com.example.labo4android;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUser;
    private EditText editTextPwd;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUser = findViewById(R.id.editTextUser);
        editTextPwd = findViewById(R.id.editTextPwd);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               login(v);
            }
        });


    }


    public void login (View v){
        String user = this.editTextUser.getText().toString();
        String pwd = this.editTextPwd.getText().toString();

        dbWorker dbw = new dbWorker(this);
        dbw.execute(0,user,pwd);
    }
    public  static class dbWorker extends AsyncTask {


        private AlertDialog.Builder alertDialogBuilder;
        private Context c;
        private AlertDialog ad;

        private final String[] urls ={"login.php","inscription.php","activities.php",
                "listeInscription.php","inscrireAct.php","notemoyenne.php","noteAct.php","proposerAct.php","stats.php","updateAcc.php"};
        private final int login = 0;
        private final int inscription = 1;
        private final int activities = 2;
        private final int listeInscription = 3;
        private final int inscrireAct = 4;
        private final int notemoyenne = 5;
        private final int noteAct = 6;
        private final int proposerAct = 7;
        private final int stats = 8;
        private final int updateAcc = 9 ;



        public dbWorker (Context c ){
            this.c=c;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           this.ad = new AlertDialog.Builder(this.c).create();
            this.ad.setTitle("informations");
        }

        @Override
        protected Object doInBackground (Object[] objects) {

            int cmd = (int) objects[0];
            switch (cmd){
                case login :
                    String ciblelogin =  "http://10.1.10.107/dashboard/android1/" + urls[login];
            String user =objects[1].toString(); //
            String pwd = objects[2].toString();

            try {
                URL url = new URL(ciblelogin);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setDoInput(true);
                con.setDoOutput(true);
                con.setRequestMethod("POST");

                OutputStream outs = con.getOutputStream();
                BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                String msg = URLEncoder.encode("user","UTF-8")+"="+
                        URLEncoder.encode((String)objects[1],"UTF-8")+
                        "&"+URLEncoder.encode("pwd","UTF-8")+"="+
                        URLEncoder.encode((String)objects[2],"UTF-8");

                bufw.write(msg);
                bufw.flush();
                bufw.close();
                outs.close();

                InputStream ins = con.getInputStream();
                BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                String line;
                StringBuffer sbuff = new StringBuffer();

                while ((line = bufr.readLine()) != null) {
                    sbuff.append(line + "\n");
                }
                return sbuff.toString();
            }
            catch (Exception ex) {

                return ex.getMessage();
        }

                case inscription :
                    String cibleInscription = "http://172.29.98.58/dashboard/android1/" + urls[inscription];
                    String nom = String.valueOf(objects[1]);
                    String prenom = String.valueOf(objects[2]);
                    String tel = String.valueOf(objects[3]);
                    String email = String.valueOf(objects[4]);
                    String username = String.valueOf(objects[5]);
                    String password = String.valueOf(objects[6]);


                    try {
                        URL url = new URL(cibleInscription);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        String msg = URLEncoder.encode("nom","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8")+
                                "&"+URLEncoder.encode("prenom","UTF-8")+"="+
                                URLEncoder.encode((String)objects[2],"UTF-8")+
                                "&"+URLEncoder.encode("tel","UTF-8")+"="+
                                URLEncoder.encode((String)objects[3],"UTF-8")+
                                "&"+URLEncoder.encode("email","UTF-8")+"="+
                                URLEncoder.encode((String)objects[4],"UTF-8")+
                                "&"+URLEncoder.encode("username","UTF-8")+"="+
                                URLEncoder.encode((String)objects[5],"UTF-8")+
                                "&"+URLEncoder.encode("password","UTF-8")+"="+
                                URLEncoder.encode((String)objects[6],"UTF-8");


                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    }
                    catch (Exception ex) {
                        return ex.getMessage();
                    }

                case updateAcc :
                    String cibleupdateAcc = "http://192.168.0.191/dashboard/android1/" + urls[updateAcc];
                    String id = String.valueOf(objects[1]);
                    nom = String.valueOf(objects[2]);
                     prenom = String.valueOf(objects[3]);
                     tel = String.valueOf(objects[4]);
                     email = String.valueOf(objects[5]);
                     username = String.valueOf(objects[6]);
                     password = String.valueOf(objects[7]);


                    try {
                        URL url = new URL(cibleupdateAcc);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        String msg = URLEncoder.encode("id","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8")+
                                "&"+URLEncoder.encode("nom","UTF-8")+"="+
                                URLEncoder.encode((String)objects[2],"UTF-8")+
                                "&"+URLEncoder.encode("prenom","UTF-8")+"="+
                                URLEncoder.encode((String)objects[3],"UTF-8")+
                                "&"+URLEncoder.encode("tel","UTF-8")+"="+
                                URLEncoder.encode((String)objects[4],"UTF-8")+
                                "&"+URLEncoder.encode("email","UTF-8")+"="+
                                URLEncoder.encode((String)objects[5],"UTF-8")+
                                "&"+URLEncoder.encode("username","UTF-8")+"="+
                                URLEncoder.encode((String)objects[6],"UTF-8")+
                                "&"+URLEncoder.encode("password","UTF-8")+"="+
                                URLEncoder.encode((String)objects[7],"UTF-8");


                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    }
                    catch (Exception ex) {
                        return ex.getMessage();
                    }

                case activities :
                    String cibleActivities = "http://10.1.10.87/dashboard/android1/" + urls[activities];
                    try {
                        URL url = new URL(cibleActivities);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");
                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    } catch (Exception ex) {
                        return ex.getMessage();
                    }
                case proposerAct :
                    String ciblePropAct= "http://10.1.10.87/dashboard/android1/" + urls[proposerAct];
                    String titre = String.valueOf(objects[1]);
                    String dateDebut = String.valueOf(objects[2]);
                    String dateFin = String.valueOf(objects[3]);
                    String description = String.valueOf(objects[4]);
                    String prix = String.valueOf(objects[5]);

                    try {
                        URL url = new URL(ciblePropAct);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs, "UTF-8"));

                        String msg = URLEncoder.encode("titre","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8")+
                                "&"+URLEncoder.encode("dateDebut","UTF-8")+"="+
                                URLEncoder.encode((String)objects[2],"UTF-8")+
                                "&"+URLEncoder.encode("dateFin","UTF-8")+"="+
                                URLEncoder.encode((String)objects[3],"UTF-8")+
                                "&"+URLEncoder.encode("description","UTF-8")+"="+
                                URLEncoder.encode((String)objects[4],"UTF-8")+
                                "&"+URLEncoder.encode("prix","UTF-8")+"="+
                                URLEncoder.encode((String)objects[5],"UTF-8");
                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins, "iso-8859-1"));
                        String line;
                        StringBuilder sbuff = new StringBuilder();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line).append("\n");
                        }
                        return sbuff.toString();
                    } catch (Exception ex) {
                        return ex.getMessage();
                    }
                case inscrireAct :
                    String cibleisnscrireAct =  "http://192.168.0.191/dashboard/android1/" + urls[inscrireAct];
                    String id_util =objects[1].toString(); //
                    String id_act = objects[2].toString();

                    try {
                        URL url = new URL(cibleisnscrireAct);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        String msg = URLEncoder.encode("id_util","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8")+
                                "&"+URLEncoder.encode("id_act","UTF-8")+"="+
                                URLEncoder.encode((String)objects[2],"UTF-8");

                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    }
                    catch (Exception ex) {

                        return ex.getMessage();
                    }
                case noteAct :
                    String ciblenoteAct =  "http://192.168.0.191/dashboard/android1/" + urls[noteAct];
                     id_util =objects[1].toString(); //
                     id_act = objects[2].toString();
                   String note = objects[3].toString();


                    try {
                        URL url = new URL(ciblenoteAct);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        String msg = URLEncoder.encode("id_util","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8")+
                                "&"+URLEncoder.encode("id_act","UTF-8")+"="+
                                URLEncoder.encode((String)objects[2],"UTF-8")+
                                "&"+URLEncoder.encode("note","UTF-8")+"="+
                                URLEncoder.encode((String)objects[3],"UTF-8");

                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    }
                    catch (Exception ex) {

                        return ex.getMessage();
                    }
                case stats:
                    String ciblestats =  "http://192.168.0.191/dashboard/android1/" + urls[stats];
                    id_act =objects[1].toString();
                    try {
                        URL url = new URL(ciblestats);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        String msg = URLEncoder.encode("id_act","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8");
                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    }
                    catch (Exception ex) {

                        return ex.getMessage();
                    }
                case notemoyenne:
                    String ciblenote =  "http://192.168.0.191/dashboard/android1/" + urls[notemoyenne];
                    id_act =objects[1].toString();
                    try {
                        URL url = new URL(ciblenote);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        String msg = URLEncoder.encode("id_act","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8");
                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    }
                    catch (Exception ex) {

                        return ex.getMessage();
                    }
                case listeInscription:
                    String ciblelstInscri =  "http://192.168.0.191/dashboard/android1/" + urls[listeInscription];
                    id_act =objects[1].toString();
                    try {
                        URL url = new URL(ciblelstInscri);
                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                        con.setDoInput(true);
                        con.setDoOutput(true);
                        con.setRequestMethod("POST");

                        OutputStream outs = con.getOutputStream();
                        BufferedWriter bufw = new BufferedWriter(new OutputStreamWriter(outs,"UTF-8"));

                        String msg = URLEncoder.encode("id_act","UTF-8")+"="+
                                URLEncoder.encode((String)objects[1],"UTF-8");
                        bufw.write(msg);
                        bufw.flush();
                        bufw.close();
                        outs.close();

                        InputStream ins = con.getInputStream();
                        BufferedReader bufr = new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
                        String line;
                        StringBuffer sbuff = new StringBuffer();

                        while ((line = bufr.readLine()) != null) {
                            sbuff.append(line + "\n");
                        }
                        return sbuff.toString();
                    }
                    catch (Exception ex) {

                        return ex.getMessage();
                    }

            }

            return null;
        }




        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            this.ad.setMessage((String)o);
            this.ad.show();




        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
         super.onCreateOptionsMenu(menu);
         menu.add(Menu.NONE,Menu.FIRST+0,0,"inscription");
        menu.add(Menu.NONE,Menu.FIRST+1,1,"voir les activités");
        menu.add(Menu.NONE,Menu.FIRST+2,2,"s'inscrire a une activité");
        menu.add(Menu.NONE,Menu.FIRST+3,3,"proposer une activité");
        menu.add(Menu.NONE,Menu.FIRST+4,4,"noter une activité");
        menu.add(Menu.NONE,Menu.FIRST+5,5,"statistiques");
        menu.add(Menu.NONE,Menu.FIRST+6,6,"liste des inscriptions");
        menu.add(Menu.NONE,Menu.FIRST+7,7,"note moyenne");
        menu.add(Menu.NONE,Menu.FIRST+8,8,"updateAcc");
         return true ;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        Intent i = null;
        switch (item.getItemId()){
            case Menu.FIRST:
                i = new Intent (getApplicationContext (), inscription.class);
                break;
            case Menu.FIRST + 1:
                i = new Intent (getApplicationContext (), voir_les_activites.class);
                break;
            case Menu.FIRST + 2:
                i = new Intent (getApplicationContext (),inscrire_a_une_activite.class);
                break;
            case Menu.FIRST + 3:
                i = new Intent (getApplicationContext (),proposer_une_activite. class);
                break;
            case Menu.FIRST + 4:
                i = new Intent (getApplicationContext (), noter_une_activite.class);
                break;
            case Menu.FIRST + 5:
                i = new Intent (getApplicationContext(),statistique. class);
            break;
            case Menu. FIRST + 6:
                i = new Intent (getApplicationContext (), listedes_inscriptions.class);
                break;
            case Menu.FIRST + 7:
                i = new Intent (getApplicationContext (),note_moyenne. class);
                break;
            case Menu.FIRST + 8:
                i = new Intent (getApplicationContext (),updateAcc. class);
                break;
        }
        startActivity(i);
        return true;
    }
}


