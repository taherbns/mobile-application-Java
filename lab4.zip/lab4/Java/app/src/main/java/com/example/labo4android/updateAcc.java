package com.example.labo4android;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class updateAcc extends AppCompatActivity {
    private EditText textid;
    private EditText editTextNom;
    private EditText editTextPrenom;
    private EditText editTexttel;
    private EditText editTextemail;
    private EditText editTextusername;
    private EditText editTextpassword;

    private Button modifier;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_acc);

        textid =findViewById(R.id.textid);
        editTextNom = findViewById(R.id.editTextNom);
        editTextPrenom = findViewById(R.id.editTextPrenom);
        editTexttel = findViewById(R.id.editTextTel);
        editTextemail = findViewById(R.id.editTextemail);
        editTextusername = findViewById(R.id.editTextuser);
        editTextpassword = findViewById(R.id.editTextpwd);
        modifier = findViewById(R.id.buttonModifier);

    modifier.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            modifierCompte();
        }
    });


    }

    private void modifierCompte() {
        String id = textid.getText().toString().trim();
        String nom = editTextNom.getText().toString().trim();
        String prenom = editTextPrenom.getText().toString().trim();
        String tel = editTexttel.getText().toString().trim();
        String email = editTextemail.getText().toString().trim();
        String username = editTextusername.getText().toString().trim();
        String password = editTextpassword.getText().toString().trim();
        MainActivity.dbWorker dbr = new MainActivity.dbWorker(this);
        dbr.execute(9,id, nom, prenom, tel, email, username, password);
    }
}
