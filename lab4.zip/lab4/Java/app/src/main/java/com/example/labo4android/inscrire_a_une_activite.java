package com.example.labo4android;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class inscrire_a_une_activite extends AppCompatActivity {
    private EditText editTextUserId;
    private EditText editTextActivityId;
    private EditText texttitre;
    private Button buttonInscription;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inscritact);


        editTextUserId = findViewById(R.id.editTextUserId);
        editTextActivityId = findViewById(R.id.editTextActivityId);
        texttitre = findViewById(R.id.titre);
        buttonInscription = findViewById(R.id.buttonInscription);

        buttonInscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inscrireAct();
            }
        });
    }

    private void inscrireAct() {
        String id_util = editTextUserId.getText().toString().trim();
        String id_act = editTextActivityId.getText().toString().trim();
        String titre = texttitre.getText().toString().trim();
        MainActivity.dbWorker d = new MainActivity.dbWorker(this);
        d.execute(4,id_util,id_act);
    }
}
