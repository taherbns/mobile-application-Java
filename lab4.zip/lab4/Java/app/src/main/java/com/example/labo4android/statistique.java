package com.example.labo4android;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class statistique extends AppCompatActivity {

    private EditText editTextActivityId;
    private Button buttonGetCount;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stats);
        editTextActivityId = findViewById(R.id.editTextActivityId);
        buttonGetCount = findViewById(R.id.buttonGetCount);

        buttonGetCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count();
            }
        });
    }

    private void count() {
        String id_act = editTextActivityId.getText().toString().trim();
        MainActivity.dbWorker d = new MainActivity.dbWorker(this);
        d.execute(8,id_act);
    }
}
