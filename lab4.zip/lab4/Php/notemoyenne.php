<?php

$Surl = "mysql:host=localhost;dbname=android";
$dbuser = "root";
$dbpw = "";

try {
   
    $dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $id_act = $_POST['id_act'];

   
    $sql = "SELECT note FROM noteActivity WHERE id_act = ?";
    $stmt = $dbcon->prepare($sql);
    $stmt->execute([$id_act]);
    $notes = $stmt->fetchAll(PDO::FETCH_COLUMN);

    
    $nombre_de_notes = count($notes);
    if ($nombre_de_notes > 0) {
        $somme_des_notes = array_sum($notes);
        $note_moyenne = $somme_des_notes / $nombre_de_notes;
        echo "la note moyenne de l'activite est : " . $note_moyenne;
    } else {
        echo "aucune note pour cette activite.";
    }
} catch(PDOException $e) {
    echo "Erreur lors du calcul de la note moyenne : " . $e->getMessage();
}


$dbcon = null;
?>
