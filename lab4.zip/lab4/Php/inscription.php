<?php
try {
    $Surl = "mysql:host=localhost;dbname=android";
    $dbuser = "root";
    $dbpw = "";
    
    
    $dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if (
        isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['tel'])
        && isset($_POST['email']) && isset($_POST['username']) && isset($_POST['password'])
    ) {
        $username = $_POST['username'];
        $password = $_POST['password'];

      
         $checkUser = $dbcon->prepare("SELECT * FROM inscription WHERE username = ?");
          $checkUser->execute([$username]);
         $userCount = $checkUser->fetchColumn();

        if ($userCount > 0) {
                    echo "Le nom d'utilisateur existe deja , veuillez vous connecter.";
        } else {
            
             $insertUser = $dbcon->prepare(
                "INSERT INTO inscription (nom, prenom, tel, email, username, password) VALUES (?, ?, ?, ?, ?, ?)"
            );
        $insertUser->execute([$nom, $prenom, $tel, $email, $username, $password]);

            echo "Inscription reussie!";
        }
    
    } else { echo "Veuillez fournir tout les information necessaires pour l'inscription.";
    }

} catch (PDOException $ex) {
    
    echo $ex->getMessage();
}













?>