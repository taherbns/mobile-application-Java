<?php

if (isset($_POST['titre'], $_POST['dateDebut'], $_POST['dateFin'], $_POST['description'], $_POST['prix'])) {

    
    $Surl = "mysql:host=localhost;dbname=android";
    $dbuser = "root";
    $dbpw = "";

    try {
    
        $dbcon = new PDO($Surl, $dbuser, $dbpw);
        $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

       
        $titre = $_POST['titre'];
        $dateDebut = $_POST['dateDebut'];
        $dateFin = $_POST['dateFin'];
        $description = $_POST['description'];
        $prix = $_POST['prix'];

        
    $sql = "INSERT INTO propactivite (titre, dateDebut, dateFin, description, prix) VALUES (?, ?, ?, ?, ?)";
        
        
     $stmt = $dbcon->prepare($sql);
     $stmt->execute([$titre, $dateDebut, $dateFin, $description, $prix]);
      echo "Nouvelle activite ajoutee avec success !";

       
      $dbcon = null;
    } 
    catch (PDOException $e) {
    
        echo "Erreur : " . $e->getMessage();
    
    }
} 
else {
    echo "Tous les champs requis ne sont pas definis.";
}
?>
