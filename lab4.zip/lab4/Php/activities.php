<?php

$Surl = "mysql:host=localhost;dbname=android";
$dbuser = "root";
$dbpw = "";

$dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "SELECT titre, dateDebut, dateFin, description, prix FROM activites";
    $result = $dbcon->query($sql);

if ($result->rowCount() > 0) {
         while($row = $result->fetch(PDO::FETCH_ASSOC)) {
 echo "Titre: " . $row['titre'] . "\n";
    echo "Date de debut: " . $row['dateDebut'] . "\n";
       echo "Date de fin: " . $row['dateFin'] . "\n";
      echo "Description: " . $row['description'] . "\n";
    echo "Prix: " . $row['prix'] . "\n";
        echo "\n"; 
    }
} else {
    echo "0 results";
}
?>
