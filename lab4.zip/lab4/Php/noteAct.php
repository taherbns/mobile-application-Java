<?php

$Surl = "mysql:host=localhost;dbname=android";
$dbuser = "root";
$dbpw = "";

try {
    
    $dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
     $id_util = $_POST['id_util'];
    $id_act= $_POST['id_act'];
     $note = $_POST['note']; 

    
     $sqlCheck = "SELECT * FROM inscritact WHERE id_util = ? AND id_act = ?";
    $stmtCheck = $dbcon->prepare($sqlCheck);
     $stmtCheck->execute([$id_util, $id_act]);
     $result = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        
        $sql = "INSERT INTO noteactivity (id_util, id_act, note) VALUES (?, ?, ?)";
        $stmt = $dbcon->prepare($sql);
        $stmt->execute([$id_util, $id_util, $note]);

        echo "Note ajouteé avec success !";
    } else {   echo "utilisateur non inscrit a cette activite. Impossible d'ajouter la note.";
    }
} catch(PDOException $e) {
    echo "Erreur lors de l'ajout de la note : " . $e->getMessage();
}

// Fermeture de la connexion
$dbcon = null;
?>
