<?php

$Surl = "mysql:host=localhost;dbname=android";
$dbuser = "root";
$dbpw = "";

try {
   
    $dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $id_util = $_POST['id_util'];
    $id_act = $_POST['id_act'];

    
  $sql = "INSERT INTO inscritact (id_util, id_act) VALUES (?, ?)";
$stmt = $dbcon->prepare($sql);
 $stmt->execute([$id_util, $id_act]);

    echo "Utilisateur inscrit à l'activite avec success !";
} catch(PDOException $e) {
    echo "Erreur lors de l'inscription : " . $e->getMessage();
}


$dbcon = null;
?>
