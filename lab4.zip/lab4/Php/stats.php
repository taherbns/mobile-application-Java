<?php

$Surl = "mysql:host=localhost;dbname=android";
$dbuser = "root";
$dbpw = "";

try {
   
    $dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

   
    $id_act = $_POST['id_act'];


    $sql = "SELECT COUNT(*) AS nombre_inscriptions FROM inscritact WHERE id_act = ?";
    $stmt = $dbcon->prepare($sql);

    $stmt->execute([$id_act]);
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    echo $result['nombre_inscriptions']; 
} catch(PDOException $e) { echo "Erreur : " . $e->getMessage();

}


$dbcon = null;
?>
