<?php

$Surl = "mysql:host=localhost;dbname=android";
$dbuser = "root";
$dbpw = "";

try {
 
    $dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $id = $_POST['id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $tel = $_POST['tel'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password']; 

   
     $sql = "UPDATE inscription SET nom=?, prenom=?, tel=?, email=?, username=?, password=? WHERE id=?";
      $stmt = $dbcon->prepare($sql);

      $stmt->execute([$nom, $prenom, $tel, $email, $username, $password,$id,]);

    
     echo "Informations mises a jour avec success !";
    } 
    catch(PDOException $e) {

        echo "Erreur lors de la mise a jour des informations : " . $e->getMessage();

}


$dbcon = null;
?>
