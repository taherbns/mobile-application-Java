<?php
try {
    
    $Surl = "mysql:host=localhost;dbname=android";
    $dbuser = "root";
    $dbpw = "";
    
   
    $dbcon = new PDO($Surl, $dbuser, $dbpw);
    $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
   
    $SutilUser = $_POST['user'];
    $SutilPw = $_POST['pwd'];


    
    
     $Scmd = $dbcon->prepare("SELECT nom, prenom FROM utilisateur WHERE user = ? AND pwd = ?;");
     $data = array($SutilUser, $SutilPw);
      $Scmd-> execute($data);
    
      $Sout = "";
    
    while ($Sline = $Scmd->fetchObject()) {
        $Sout .= $Sline->nom . " " . $Sline->prenom;
    }
    
    echo $Sout;
} 
catch (PDOException $ex) {
    echo $ex->getMessage();
}
?>
