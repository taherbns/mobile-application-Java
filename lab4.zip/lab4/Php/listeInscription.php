<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "android";

try {
    
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $id_act = $_POST['id_act']; 

    $sql = "SELECT utilisateur.nom FROM utilisateur 
            INNER JOIN inscritact ON utilisateur.id_util = inscritact.id_util 
            WHERE inscritact.id_act = :id_act";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_act', $id_act);
    $stmt->execute();

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($result) > 0) {
       
        foreach ($result as $row) {
            echo $row['nom'] ;
        }
    } else {
        echo "aucun utilisateur inscrit a cette activite.";
    }
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}


$conn = null;
?>
